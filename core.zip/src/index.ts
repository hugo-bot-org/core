import { Test } from "./test";

export class HUGO {
    public constructor() {
        Test.testPin23();
    }
}

new HUGO();