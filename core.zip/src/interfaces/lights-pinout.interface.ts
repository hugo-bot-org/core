export interface LightsPinout {
    A: number;
    B: number;
}
