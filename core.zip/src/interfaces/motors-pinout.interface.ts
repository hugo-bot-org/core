export interface MotorsPinout {
    A: {
        FWD: number;
        BWD: number;
    };

    B: {
        FWD: number;
        BWD: number;
    };

    driver: number;
}
