export interface Factory {
    instance: any;
    resolve(): any;
}
