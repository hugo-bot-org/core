export const INSTANCES = {
    WPI: 'WPI',
    Lighting: 'Lighting',
    Propulsion: 'Propulsion',
}