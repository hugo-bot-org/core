export const INSTANCES = {
    WPI: 'WPIInstance'
}