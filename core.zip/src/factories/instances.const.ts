export const INSTANCES = {
    WPI: 'WPI',
    Propulsion: 'Propulsion'
}
