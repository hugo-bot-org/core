import * as SLEEP from 'sleep';
import * as WPI from 'wiringpi-node';

export class Test {
    public static testPin23() {
        WPI.wiringPiSetupGpio();
        WPI.pinMode(23, WPI.OUTPUT);

        WPI.digitalWrite(23, 0);
        SLEEP.msleep(500);
        WPI.digitalWrite(23, 1);
    }
}