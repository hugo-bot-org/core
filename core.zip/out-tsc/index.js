"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const test_1 = require("./test");
class HUGO {
    constructor() {
        test_1.Test.testPin23();
    }
}
exports.HUGO = HUGO;
new HUGO();
