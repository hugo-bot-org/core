"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.INSTANCES = {
    WPI: 'WPI',
    Lighting: 'Lighting',
    Propulsion: 'Propulsion',
};
